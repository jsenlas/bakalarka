# Arduino-Bluetooth-Basic
Control a LED using your smartphone via bluetooth
Download the app from here : http://goo.gl/PSXVoF

Tutorial : https://igniteinnovateideas.wordpress.com/2016/04/18/arduino-bluetooth-basic-tutorial/

Website : https://http://mayooghgirish.ml

<h2><B>NOTE : This Application does not support Bluetooth Low Energy (BLE). Only works with SPP</B></h2>


